---
name: LeadOS project state
description: Current state of the LeadOS platform build — page counts, test counts, architecture decisions, what's been built
type: project
---

LeadOS is a multi-tenant lead generation OS at pinohu/lead-os. Two deployment targets:
- **Hybrid runtime** (Next.js 16, pure CSS, 502 pages, 4109 tests) — kernel with 295 API endpoints, 27 dashboard pages
- **Neatcircle-beta** (Next.js 15, Tailwind, 152 pages) — edge/marketing layer

**Why:** Config-driven multi-tenant architecture. One env var bootstraps any of 22 client presets. Not 50 separate codebases — one codebase serving 654 pages across 16 industry verticals.

**How to apply:** All new pages follow the ExperienceScaffold + AdaptiveLeadCaptureForm pattern. Pages use `data-niche` CSS attribute for per-industry theming. generateStaticParams iterates nicheCatalog for SSG. Source prop on forms must be a valid IntakeSource type.
